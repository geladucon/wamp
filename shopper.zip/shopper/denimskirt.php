<?php require_once('includes/header.php'); ?>

		<div id="top-bar" class="container">
			<div class="row">
				<div class="span4">
					<form method="POST" class="search_form">
						<input type="text" class="input-block-level search-query" Placeholder="SEARCH ...">
					</form>
				</div>
				<div class="span8">
					<div class="account pull-right">
						<ul class="user-menu">				
							<li><a href="#">MY ACCOUNT</a></li>
							<li><a href="cart.php">YOUR CART</a></li>
							<li><a href="checkout.php">CHECKOUT</a></li>					
							
                  
                 	
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div id="wrapper" class="container">
			<section class="navbar main-menu">
				<div class="navbar-inner main-menu">				
					<a href="index.html" class="logo pull-left"><img src="themes/images/logo.png" class="site_logo" alt=""></a>
					<nav id="menu" class="pull-right">
						<ul>
							<li><a href="./homepage.php">HOME</a>
							<li><a href="./products.php">PRODUCTS</a></li>															
							<li><a href="./contact.html">CONTACT US</a></li>			
							<li><a href="./products.html">HOW TO ORDER</a>
						</ul>
					</nav>
				</div>
			</section>
			<section class="header_text sub">
			<img class="pageBanner" src="themes/images/pageBanner.png" alt="New products" >
				<h4><span>Product Detail</span></h4>
			</section>
			<section class="main-content">				
				<div class="row">						
					<div class="span9">
						<div class="row">
							<div class="span4">
								<a href="PRODUCTS/denimskirt.jpg" class="thumbnail" data-fancybox-group="group1" title="Description 1"><img alt="" src="PRODUCTS/denimskirt.jpg"></a>												
								
							</div>
							<div class="span5">
								<address>
									
									<strong>Product Code:</strong> <span>DENIM SKIRT</span><br>
									<strong>Availability:</strong> <span>PRE ORDER</span><br>								
								</address>									
								<h4><strong>Price: ₱210.00</strong></h4>
							</div>
							<div class="span5">
								
									<label>Qty:</label>
									<input type="text" class="span1" placeholder="1">
									<a href="cartdenim.php" class="btn btn-inverse" type="submit">Add to cart</a>
								</div>
							</div>
						</div>

						<div class="span3 col">
						<div class="block">	
							<ul class="nav nav-list">
								<li class="nav-header">WOMEN'S APPAREL</li>
								<li><a href="products.html">DRESSES</a></li>
								<li class="active"><a href="products.html">TOPS</a></li>
								<li><a href="products.html">PANTS</a></li>
								<li><a href="products.html">SKIRTS</a></li>
								<li><a href="products.htmSl">SHORTS</a></li>
								<li><a href="products.htmSl">JACKET & BLAZERS</a></li>
								<li><a href="products.htmSl">JUMPSUITS & ROMPERS</a></li>
								
							</ul>
								</form>
							</div>							
						</div>
					</div>


						<div class="pull-left">
						<div class="row">
							<div class="span9">
								<ul class="nav nav-tabs" id="myTab">
									
									<li class="active"><a href="#profile">Description</a></li>
								</ul>							 
								
									<div class="tab-pane active" id="profile">
										<table class="table table-striped shop_attributes">	
											<tbody>
												<tr class="">
													<th>ONE ROW BUTTONS DENIM SKIRT</th>
												
												</tr>		
												<tr class="alt">
													<th>LIGHT BLUE </th>
													
												</tr>
												<tr class="alt">
													<th>SIZE: 28 </th>
													
												</tr>
												<tr class="alt">
													<th>A-LINE SKIRTS</th>
													
												</tr>

											</tbody>
										</table>
									</div>
								</div>		
							
						
												</div>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						
								</li>   
							</ul>
						</div>
					</div>
				</div>
			</section>			
			<section id="footer-bar">
				<div class="row">
					<div class="span3">
						<h4>Navigation</h4>
						<ul class="nav">
							<li><a href="./index.html">Homepage</a></li>  
							<li><a href="./about.html">About Us</a></li>
							<li><a href="./contact.html">Contac Us</a></li>
							<li><a href="./cart.html">Your Cart</a></li>
							<li><a href="./register.html">Login</a></li>							
						</ul>					
					</div>
					<div class="span4">
						<h4>My Account</h4>
						<ul class="nav">
							<li><a href="#">My Account</a></li>
							<li><a href="#">Order History</a></li>
							<li><a href="#">Wish List</a></li>
							<li><a href="#">Newsletter</a></li>
						</ul>
					</div>
					<div class="span5">
						<p class="logo"><img src="themes/images/logo.png" class="site_logo" alt=""></p>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. the  Lorem Ipsum has been the industry's standard dummy text ever since the you.</p>
						<br/>
						<span class="social_icons">
							<a class="facebook" href="#">Facebook</a>
							<a class="twitter" href="#">Twitter</a>
							<a class="skype" href="#">Skype</a>
							<a class="vimeo" href="#">Vimeo</a>
						</span>
					</div>					
				</div>	
			</section>
			<section id="copyright">
				<span>Copyright 2013 bootstrappage template  All right reserved.</span>
			</section>
		</div>
		<script src="themes/js/common.js"></script>
		<script>
			$(function () {
				$('#myTab a:first').tab('show');
				$('#myTab a').click(function (e) {
					e.preventDefault();
					$(this).tab('show');
				})
			})
			$(document).ready(function() {
				$('.thumbnail').fancybox({
					openEffect  : 'none',
					closeEffect : 'none'
				});
				
				$('#myCarousel-2').carousel({
                    interval: 2500
                });								
			});
		</script>
    </b
    <body>
</html>