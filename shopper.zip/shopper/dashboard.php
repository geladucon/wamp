<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title> Dashboard</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="../admin/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- dropzone -->
  <link rel="stylesheet" href="../admin/css/dropzone.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../admin/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="../admin/bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../admin/dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../admin/dist/css/skins/_all-skins.min.css">
  <!-- Morris chart -->
  <link rel="stylesheet" href="../admin/bower_components/morris.js/morris.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="../admin/bower_components/jvectormap/jquery-jvectormap.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="../admin/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="../admin/bower_components/bootstrap-daterangepicker/daterangepicker.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="../admin/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">

  <link rel="stylesheet" href="../admin/bower_components/select2/dist/css/select2.min.css">

  <link rel="stylesheet" href="../admin/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">


  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">

  <!-- jQuery 3 -->
  <script src="../admin/bower_components/jquery/dist/jquery.min.js"></script>
  <!-- jQuery UI 1.11.4 -->
  <script src="../admin/bower_components/jquery-ui/jquery-ui.min.js"></script>
  <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
  <script>
    $.widget.bridge('uibutton', $.ui.button);
  </script>
  <!-- Bootstrap 3.3.7 -->
  <script src="../admin/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
  <!-- Morris.js charts -->
  <script src="../admin/bower_components/raphael/raphael.min.js"></script>
  <script src="../admin/bower_components/morris.js/morris.min.js"></script>
  <!-- Sparkline -->
  <script src="../admin/bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
  <!-- jvectormap -->
  <script src="../admin/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
  <script src="../admin/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
  <!-- jQuery Knob Chart -->
  <script src="../admin/bower_components/jquery-knob/dist/jquery.knob.min.js"></script>
  <!-- daterangepicker -->
  <script src="../admin/bower_components/moment/min/moment.min.js"></script>
  <script src="../admin/bower_components/bootstrap-daterangepicker/daterangepicker.js"></script>
  <!-- datepicker -->
  <script src="../admin/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
  <!-- Bootstrap WYSIHTML5 -->
  <script src="../admin/plugins/iCheck/icheck.min.js"></script>

  <script src="../admin/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
  <!-- Slimscroll -->
  <script src="../admin/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
  <!-- FastClick -->
  <script src="../admin/bower_components/fastclick/lib/fastclick.js"></script>
  <!-- DataTables -->
  <script src="../admin/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
  <script src="../admin/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
  <!-- input mask -->
    <script src="../admin/bower_components/select2/dist/js/select2.full.min.js"></script>
  <!-- InputMask -->
  <script src="../admin/plugins/input-mask/jquery.inputmask.js"></script>
  <script src="../admin/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
  <script src="../admin/plugins/input-mask/jquery.inputmask.extensions.js"></script>
  <!-- AdminLTE App -->
  <script src="../admin/dist/js/adminlte.min.js"></script>
  <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
  <script src="../admin/dist/js/pages/dashboard.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script type="text/javascript" src="../admin/js/dropzone.min.js"></script>
  <!-- dropzone JS -->

  
</head>
<body class="hold-transition skin-blue sidebar-mini">
  
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="index2.html" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>A</b>LT</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Dashboard</b></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="dist/img/user2-160x160.jpg" class="user-image" alt="User Image">
              <span class="hidden-xs">Alexander Pierce</span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">

                <p>
                  Angela Ducon 
                </p>
              </li>
              <li class="user-footer">
                <div class="pull-left">
                  <a href="#" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="../admin/logout.php" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>Alexander Pierce</p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <li class="sub-admin">
          <a href="../admin/dashboard.php">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>

        <li class="treeview sub-users">
          <a href="#">
            <i class="fa fa-users"></i>
            <span>Users</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="treeview-menu-users" id="sub_users"><a href="../admin/users.php"><i class="fa fa-circle-o"></i> Users</a></li>
            <li class="treeview-menu-users" id="confirm_users"><a href="../admin/confirm_users.php"><i class="fa fa-circle-o"></i> Confirm User</a></li>
            <li class="treeview-menu-users" id="create_users"><a href="../admin/create_users.php"><i class="fa fa-circle-o"></i> Create New Users </a></li>
          </ul>
        </li>

        <li class="treeview sub-employee">
          <a href="#">
            <i class="fa fa-users"></i>
            <span> Employees</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="treeview-menu-users"><a href="../admin/employee.php"><i class="fa fa-circle-o"></i> Employee </a></li>
            <li ><a href="../admin/create_employee.php"><i class="fa fa-circle-o"></i> Create New Employee </a></li>
          </ul>
        </li>

        <li class="treeview sub-assets">
          <a href="../admin/assets.php">
            <i class="fa fa-book"></i> <span>Assets</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="treeview-menu-assets"  id="sub_assets"><a href="../admin/assets.php"><i class="fa fa-circle-o"></i> Assets </a></li>
            <li class="treeview-menu-assets"  id="create_assets"><a href="../admin/create_assets.php"><i class="fa fa-circle-o"></i> Create New Assets </a></li>
            <li class="treeview-menu-assets"  id="asset_depriciation"><a href="../admin/depriciation.php?page=1"><i class="fa fa-circle-o"></i> Create Assets Depriciation </a></li>
            <li class="treeview-menu-assets"  id="return_assets"><a href="../admin/returns.php"><i class="fa fa-circle-o"></i> Items Return </a></li>
          </ul>
        </li>

        <li class="treeview sub-orders">
          <a href="../admin/assets.php">
            <i class="fa fa-book"></i> <span>Orders</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="treeview-menu-users"   id="order_details"><a href="../admin/orders.php"><i class="fa fa-circle-o"></i> Orders </a>
            <li class="treeview-menu-users"   id="confirm_payment"><a href="../admin/confirm_orders.php"><i class="fa fa-circle-o"></i> Confirm  Orders </a></li>
          </ul>
        </li>

        <li class="treeview sub-shipping">
          <a href="#">
            <i class="fa fa-truck"></i> <span> Shipping </span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="../admin/shipping.php" id="shippings" ><i class="fa fa-circle-o"></i> Shippings </a></li>
            <li><a href="../admin/delivered.php" id="shippings" ><i class="fa fa-circle-o"></i> Item Delivered </a></li>
          </ul>
        </li>

        <li class="treeview sub-payments">
          <a href="#">
            <i class="fa fa-university" aria-hidden="true"></i> <span> Bank Payments </span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="treeview-menu-payments" id="sub_bank_payment"><a href="../admin/bank_payments.php"><i class="fa fa-circle-o"></i> Bank Payments </a></li>
            <li class="treeview-menu-payments" id="sub_bank_paid"><a href="../admin/bank_paid.php"><i class="fa fa-circle-o"></i> Paid </a></li>
          </ul>
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
<script type="text/javascript">
	
	$(document).ready(function(){

		$('.sub-payments').addClass('active');
    	$('#sub_bank_payment').addClass('active');

    	$('#bank_table').DataTable();

	});

</script>


<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Bank Payments
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="../admin/dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="../admin/users.php"><i class="fa fa-users"></i> Bank Payment</a></li>
      </ol>
    </section>

    <section class="content">

    		<div class="row">

        		<div class="col-md-12">

          			<div class="box">
          					
          				</div>

            			<div class="box-header">

            				<legend> Bank Payments </legend>

	                          <div class="box-tools pull-right">

	                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
	                            
	                          </div>


            			</div>
            
          				<div class="box-body">

          					
          					<table class="table" id="bank_table">

          						<thead>
          							
          							<tr>
          								
          								<th> Order # </th>

          								<th> Payee </th>

          								<th> Receipt </th>

          								<!-- <th> Payment Action </th> -->

          							</tr>

          						</thead>

          						<tbody>

          							          							
          							<tr>
          								
          								<td>
          									 
          										<label>02e74f10e0327ad868d138f2b4fdd6f0</label>
          									 

          								</td>

          								<td> McIines Galvin</td>

          								<td>

							                <button type="button" class="btn btn-default" data-toggle="modal" data-target=".bs-example-modal-lg">Show Receipt</button>
							              </button>

          								</td>

          								<!--<td>
          									<a href="../admin/action/payments/confirm_payment.php?id=5" class="btn btn btn-primary"> Confirm </a>
          									<a href="../admin/action/payments/reject_payment.php?id=5" onclick="return confirm('Are you sure you want to Reject his payment')" class="btn btn btn-danger">  Reject  </a>
          								</td>-->

          							</tr>

          							<div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
									  <div class="modal-dialog modal-lg">
									    <div class="modal-content">

									      <div class="modal-header">
							                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
							                  <span aria-hidden="true">&times;</span></button>
							                <h4 class="modal-title">Receipt</h4>
							              </div>

							              <div class="modal-body">
							                <img src="../index/payments/2/McIines Galvin_payment_5_bir.jpg" style="width:800px;height: 500px;max-height: 800px;max-height: 500px;">
							              </div>

							              <div class="modal-footer">
							                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
							              </div>

									    </div>
									  </div>
									</div>

          							
          						</tbody>
          						
          					</table>

          				</div>

          			</div>

          		</div>

          	</div>

    </section>

</div>

<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.4.0
    </div>
    <strong>Copyright &copy; 2017 <a href="https://adminlte.io"></a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
      <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
      <!-- Home tab content -->
      <div class="tab-pane" id="control-sidebar-home-tab">
        <h3 class="control-sidebar-heading">Recent Activity</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-birthday-cake bg-red"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Langdon's Birthday</h4>

                <p>Will be 23 on April 24th</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-user bg-yellow"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Frodo Updated His Profile</h4>

                <p>New phone +1(800)555-1234</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-envelope-o bg-light-blue"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Nora Joined Mailing List</h4>

                <p>nora@example.com</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-file-code-o bg-green"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Cron Job 254 Executed</h4>

                <p>Execution time 5 seconds</p>
              </div>
            </a>
          </li>
        </ul>
        <!-- /.control-sidebar-menu -->

        <h3 class="control-sidebar-heading">Tasks Progress</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Custom Template Design
                <span class="label label-danger pull-right">70%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-danger" style="width: 70%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Update Resume
                <span class="label label-success pull-right">95%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-success" style="width: 95%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Laravel Integration
                <span class="label label-warning pull-right">50%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-warning" style="width: 50%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Back End Framework
                <span class="label label-primary pull-right">68%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-primary" style="width: 68%"></div>
              </div>
            </a>
          </li>
        </ul>
        <!-- /.control-sidebar-menu -->

      </div>
      <!-- /.tab-pane -->
      <!-- Stats tab content -->
      <div class="tab-pane" id="control-sidebar-stats-tab">Stats Tab Content</div>
      <!-- /.tab-pane -->
      <!-- Settings tab content -->
      <div class="tab-pane" id="control-sidebar-settings-tab">
        <form method="post">
          <h3 class="control-sidebar-heading">General Settings</h3>

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Report panel usage
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Some information about this general settings option
            </p>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Allow mail redirect
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Other sets of options are available
            </p>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Expose author name in posts
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Allow the user to show his name in blog posts
            </p>
          </div>
          <!-- /.form-group -->

          <h3 class="control-sidebar-heading">Chat Settings</h3>

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Show me as online
              <input type="checkbox" class="pull-right" checked>
            </label>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Turn off notifications
              <input type="checkbox" class="pull-right">
            </label>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Delete chat history
              <a href="javascript:void(0)" class="text-red pull-right"><i class="fa fa-trash-o"></i></a>
            </label>
          </div>
          <!-- /.form-group -->
        </form>
      </div>
      <!-- /.tab-pane -->
    </div>
  </aside>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->


</body>
</html>