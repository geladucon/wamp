<?php
require_once('db.php');


$username = $_POST['username'];
$password = $_POST['password'];
$userlevel;

$loginQuery = "select * from users where username = '".$username."' AND password ='".$password."'";
$row = mysqli_query($db,$loginQuery) or die(mysqli_error($db));
$result = mysqli_fetch_assoc($row);

if($result['user_level'] == 1){
	$_SESSION['username'] = $username;
	$userlevel = $_SESSION['user_level'] = $result['user_level'];
	$_SESSION['user_id'] = $result['id'];
	header('location: products.php');
}	else if($result['user_level'] == 2){
	$_SESSION['username'] = $username;
	$userlevel = $_SESSION['user_level'] = $result['user_level'];
	$_SESSION['user_id'] = $result['id'];
	header('location: dashboard.php');
}

?>