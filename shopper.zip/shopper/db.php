<?php
session_start();
//require_once('utility.php');
$db = new mysqli("localhost","root","","commerce") or die(mysqli_error());

//$db = new mysqli("localhost:3306","project9","Nzb88c^4","ticket9") or die(mysqli_error($db));
?>