<?php
require_once('includes/header.php');
require_once('db.php');

if(empty($_SESSION['user_level'])){
}	else {
	if($_SESSION['user_level'] == 1){
		header('location: products.php');
	}	else if($_SESSION['user_level'] == 2){
		header('location: dashboard.php');
	}
}
?>
		
		<div id="top-bar" class="container">
			<div class="row">
				<div class="span4">
					<form method="registration.php" class="search_form">
						<input type="text" class="input-block-level search-query" Placeholder="SEARCH ...">
					</form>
				</div>
				<div class="span8">
					<div class="account pull-right">
						<ul class="user-menu">				
							<li><a href="#">MY ACCOUNT</a></li>
							<li><a href="cart.php">YOUR CART</a></li>
							<li><a href="checkout.php">CHECKOUT</a></li>					
							<li><a href="registration.php">LOGIN</a></li>	
									
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div id="wrapper" class="container">
			<section class="navbar main-menu">
				<div class="navbar-inner main-menu">				
					<a href="index.html" class="logo pull-left"><img src="themes/images//logo.png" class="site_logo" alt=""></a>
					<nav id="menu" class="pull-right">
						<ul>
							<li><a href="./homepage.php">HOME</a>
							<li><a href="./products.php">PRODUCTS</a></li>															
							<li><a href="./contact.php">CONTACT US</a></li>			
							<li><a href="./products.html">HOW TO ORDER</a>
						</ul>
					</nav>
				</div>
			</section>			
			<section class="header_text sub">
			<img class="pageBanner" src="themes/images/pageBanner.png" alt="New products" >
				<h4><span>Login or Regsiter</span></h4>
			</section>			
			<section class="main-content">				
				<div class="row">
					<div class="span5">					
						<h4 class="title">Login Form</span></h4>
						<form action="/shopper/products.php" method="post">
							<input type="hidden" name="next" value="/">
							<fieldset>
								<div class="control-group">
									<label class="control-label">Username</label>
									<div class="controls">
										<input type="text" " name="username"  placeholder="Username" id="username" class="input-xlarge">
									</div>
								</div>
								<div class="control-group">
									<label class="control-label">Password</label>
									<div class="controls">
										<input type="password" " name="password"  placeholder="Password" id="password" class="input-xlarge">
									</div>
								</div>
								<div class="control-group">
									<input tabindex="3" class="btn btn-inverse large" type="submit" value="Sign into your account">
									<hr>
									<p class="reset">Recover your <a tabindex="4" href="#" title="Recover your username or password">username or password</a></p>
								</div>
							</fieldset>
						</form>				
					</div>


					<div class="span7">					
						<h4 class="title"><span class="text">Register Form</span></h4>
						<form action="/shopper/action/registration.php" method="POST" id="registration">
							<fieldset>
								<div class="control-group">
									<label class="control-label">Full Name</label>
									<div class="controls">
										<input type="text" " name="fullname" placeholder="Full Name" id="fullname" class="input-xlarge">
									</div>
								</div>
							
									<div class="control-group">
									<label class="control-label">Email address:</label>
									<div class="controls">
										<input type="text" " name="email" placeholder="Email" id="email" class="input-xlarge">
									</div>
								</div>	<div class="control-group">
									<label class="control-label">Contact Number:</label>
									<div class="controls">
										<input type="text" name="contactnumber" placeholder="Contact Number" id="contactnumber" class="input-xlarge">
									</div>
								</div>
								<div class="control-group">
									<label class="control-label">Username</label>
									<div class="controls">
										<input type="text" " name="username" placeholder="Username" id="username" class="input-xlarge">
									</div>
								</div>
							
								<div class="control-group">
									<label class="control-label">Password:</label>
									<div class="controls">
										<input type="password" " name="password"  placeholder="Password" id="password"  class="input-xlarge">
									</div>
								</div>							                            
								<div class="control-group">
									<p>Now that we know who you are. I'm not a mistake! In a comic, you know how you can tell who the arch-villain's going to be?</p>
								</div>
								<hr>
								<div class="actions"><input tabindex="9" class="btn btn-inverse large" type="submit" value="Create your account"></div>
							</fieldset>
						</form>					
					</div>				
				</div>
			</section>		
			<section id="footer-bar">
				<div class="row">
					<div class="span3">
						<h4>Navigation</h4>
						<ul class="nav">
							<li><a href="./index.php">Homepage</a></li>  
							<li><a href="./about.php">About Us</a></li>
							<li><a href="./contact.php">Contac Us</a></li>
							<li><a href="./cart.php">Your Cart</a></li>
							<li><a href="./register.php">Login</a></li>							
						</ul>					
					</div>
					<div class="span4">
						<h4>My Account</h4>
						<ul class="nav">
							<li><a href="#">My Account</a></li>
							<li><a href="#">Order History</a></li>
							<li><a href="#">Wish List</a></li>
							<li><a href="#">Newsletter</a></li>
						</ul>
					</div>
					<div class="span5">
						<p class="logo"><img src="themes/images/logo.png" class="site_logo" alt=""></p>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. the  Lorem Ipsum has been the industry's standard dummy text ever since the you.</p>
						<br/>
						<span class="social_icons">
							<a class="facebook" href="#">Facebook</a>
							<a class="twitter" href="#">Twitter</a>
							<a class="skype" href="#">Skype</a>
							<a class="vimeo" href="#">Vimeo</a>
						</span>
					</div>					
				</div>	
			</section>
			<section id="copyright">
				<span>Copyright 2013 bootstrappage template  All right reserved.</span>
			</section>
		</div>
		<script src="themes/js/common.js"></script>
		<script>
			$(document).ready(function() {
				$('#checkout').click(function (e) {
					document.location.href = "checkout.php";
				})
			});
		</script>		
    </body>
</html>


