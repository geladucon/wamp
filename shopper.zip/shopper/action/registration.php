<?php
require_once('../db.php');

$username = $_POST['username'];
$password = $_POST['password'];
$user_level= 1;



$registerQuery = "insert into users values (null,'$username','$password','$user_level')";
$register_result = mysqli_query($db,$registerQuery) or die(mysqli_error($db));
$users_insert_id = mysqli_insert_id($db);

$fullname = $_POST['fullname'];
$email = $_POST['email'];
$contactnumber = $_POST['contactnumber'];

$customers_query = "insert into customers values(null,'$users_insert_id','$fullname','$email','$contactnumber')";
$customers_result = mysqli_query($db,$customers_query) or die (mysqli_error($db));

header('location: ../registration.php');


?>