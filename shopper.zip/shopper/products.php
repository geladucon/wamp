<?php require_once('includes/header.php'); ?>

		<div id="top-bar" class="container">
			<div class="row">
				<div class="span4">
					<form method="POST" class="search_form">
						<input type="text" class="input-block-level search-query" Placeholder="SEARCH ...">
					</form>
				</div>
				<div class="span8">
					<div class="account pull-right">
					<ul class="user-menu">				
							<li><a href="cart.php">YOUR CART</a></li>
							<li><a href="checkout.php">CHECKOUT</a></li>
							


	
 
  <li class="dropdown">
    <button class="btn btn-inverse dropdown-toggle" type="button" data-toggle="dropdown">MY ACCOUNT
    <span class="caret"></span></button>
    <ul class="dropdown-menu">
      <li><a href="">PROFILE</a></li>
      <li><a href="logout.php">LOGOUT</a></li>
     
    </ul>
  </div>
</div>


                  
                  
                   
                   			</ul>		
						</ul>
					</div>
				</div>
			</div>
		</div>
		<br>
		<div id="wrapper" class="container">
			<section class="navbar main-menu">
				<div class="navbar-inner main-menu">				
					<a href="index.php" class="logo pull-left"><img src="" class="site_logo" alt=""></a>
					<nav id="menu" class="pull-right">
						<ul>
							<li><a href="./homepage.php">HOME</a>
							<li><a href="./products.php">PRODUCTS</a></li>															
							<li><a href="./contact.php">CONTACT US</a></li>			
							<li><a href="./products.html">HOW TO ORDER</a></ul>
					</nav>
				</div>
			</section>	
			<section class="header_text sub">
			<img class="pageBanner" src="themes/images/pageBanner.png" alt="New products" >
				<h4><span>NEW PRODUCTS</span></h4>
			</section>
			<section class="main-content">
				
				<div class="row">						
					<div class="span9">								
						<ul class="thumbnails listing-products">
							<li class="span3">
								<div class="product-box">
									<span class="sale_tag"></span>												
									<a href="product_detail.php"><img alt="" src="PRODUCTS/top.jpg"></a><br/>
									<a href="product_detail.php" class="title">HALTER SPAGHETTI TOP</a><br/>
									<a href="" class="category">LIGHT GRAY</a>
									<p class="price">₱100.00</p>
								</div>
							</li>       
							<li class="span3">
								<div class="product-box">												
									<a href="candypants.php"><img alt="" src="PRODUCTS/candypants.jpg"></a><br/>
									<a href="candypants.php" class="title">WOMAN'S CANDY PANTS</a><br/>
									<a href="candypants.php" class="category">MAROON</a>
									<p class="price">₱150.00</p>
								</div>
							</li>
							<li class="span3">
								<div class="product-box">
									<span class="sale_tag"></span>												
									<a href="bfpants.php"><img alt="" src="PRODUCTS/bfpants.jpg"></a><br/>
									<a href="bfpants.php" class="title">BOYFRIEND JEANS</a><br/>
									<a href="bfpants.php" class="category">DENIM</a>
									<p class="price">₱300.00</p>
								</div>
							</li>
							<li class="span3">
								<div class="product-box">												
									<span class="sale_tag"></span>
									<a href="knittedtop.php"><img alt="" src="PRODUCTS/knittedtop.jpg"></a><br/>
									<a href="knittedtop.php" class="title">KNITTED TOP</a><br/>
									<a href="knittedtop.php" class="category">GRAY</a>
									<p class="price">₱140.00</p>
								</div>
							</li>
							<li class="span3">
								<div class="product-box">                                        												
									<a href="denimskirt.php"><img alt="" src="PRODUCTS/denimskirt.jpg"></a><br/>
									<a href="denimskirt.php" class="title">DENIM SKIRT</a><br/>
									<a href="denimskirt.php" class="category">DENIM</a>
									<p class="price">₱210.00</p>
								</div>
							</li>       
							<li class="span3">
								<div class="product-box">												
									<a href="dress.php"><img alt="" src="PRODUCTS/dress.jpg"></a><br/>
									<a href="dress.php" class="title">LONG DRESS</a><br/>
									<a href="dress.php" class="category">MAROON</a>
									<p class="price">₱170.00</p>
								</div>
							
						<hr>
						<div class="pagination pagination-small pagination-centered">
							<ul>
								<li><a href="#">Prev</a></li>
								<li class="active"><a href="#">1</a></li>
								<li><a href="#">2</a></li>
								<li><a href="#">3</a></li>
								<li><a href="#">4</a></li>
								<li><a href="#">Next</a></li>
							</ul>
						</div>
					</div>
					<div class="span3 col">
						<div class="block">	
							<ul class="nav nav-list">
								<li class="nav-header">WOMEN'S APPAREL</li>
								<li><a href="products.html">DRESSES</a></li>
								<li class="active"><a href="products.html">TOPS</a></li>
								<li><a href="products.html">PANTS</a></li>
								<li><a href="products.html">SKIRTS</a></li>
								<li><a href="products.htmSl">SHORTS</a></li>
								<li><a href="products.htmSl">JACKET & BLAZERS</a></li>
								<li><a href="products.htmSl">JUMPSUITS & ROMPERS</a></li>
								
							</ul>
							
						
			</section>
			<section id="footer-bar">
				<div class="row">
					<div class="span3">
						<h4>Navigation</h4>
						<ul class="nav">
							<li><a href="./index.php">Homepage</a></li>  
							
							<li><a href="./contact.php">Contact Us</a></li>
							<li><a href="./cart.php">Your Cart</a></li>
							<li><a href="./register.php">Login</a></li>							
						</ul>					
					</div>
					<div class="span4">
						<h4>My Account</h4>
						<ul class="nav">
							<li><a href="#">My Account</a></li>
							<li><a href="#">Order History</a></li>
							<li><a href="#">Wish List</a></li>
							<li><a href="#">Newsletter</a></li>
						</ul>
					</div>
					<div class="span5">
						<p class="logo"><img src="PRODUCTS/LOGOS.png" class="site_logo" alt=""></p>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. the  Lorem Ipsum has been the industry's standard dummy text ever since the you.</p>
						<br/>
						<span class="social_icons">
							<a class="facebook" href="#">Facebook</a>
							<a class="twitter" href="#">Twitter</a>
							<a class="skype" href="#">Skype</a>
							<a class="vimeo" href="#">Vimeo</a>
						</span>
					</div>					
				</div>	
			</section>
			<section id="copyright">
				<span>ADapparel</span>
			</section>
		</div>
		<script src="themes/js/common.js"></script>	
    </body>
</html>